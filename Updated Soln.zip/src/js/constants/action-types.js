export const ADD_ARTICLE = "ADD_ARTICLE";
export const ADD_MOVIE = "ADD_MOVIE";