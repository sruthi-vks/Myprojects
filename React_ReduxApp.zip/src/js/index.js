import store from "../js/store/index";
import { addArticle, addMovies } from "../js/actions/index";


window.store = store;
window.addArticle = addArticle;
window.addMovies = addMovies;