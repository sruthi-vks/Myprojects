import React from "react";
import List from "./List";
import MovieLists from "./MovieLists";
import Form from "./Form";
//import { List, MovieLists } from './List';
const App = () => (
  <>
    <div>
      <h2>Articles</h2>
      <h2>Lists</h2>
      <List />
      <h2>Movie Name</h2>
      <MovieLists />
    </div>
    <div>
      <h2>Add a new article</h2>
      <Form />
    </div>
  </>
);

export default App;